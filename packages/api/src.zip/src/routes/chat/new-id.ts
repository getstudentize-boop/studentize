import { createId } from "@student/db";

export const newChatId = () => {
  return createId();
};
