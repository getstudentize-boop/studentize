ALTER TABLE "advisor" ALTER COLUMN "id" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "student" ALTER COLUMN "id" SET DATA TYPE text;