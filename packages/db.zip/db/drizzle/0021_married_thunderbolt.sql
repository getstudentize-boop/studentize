ALTER TABLE "session" ALTER COLUMN "student_user_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "session" ALTER COLUMN "advisor_user_id" DROP NOT NULL;