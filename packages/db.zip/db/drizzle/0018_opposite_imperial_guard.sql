ALTER TABLE "scheduled_session" ALTER COLUMN "advisor_user_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "scheduled_session" ALTER COLUMN "student_user_id" DROP NOT NULL;