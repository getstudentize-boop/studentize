ALTER TABLE "session" RENAME COLUMN "student_id" TO "student_user_id";--> statement-breakpoint
ALTER TABLE "session" RENAME COLUMN "advisor_id" TO "advisor_user_id";